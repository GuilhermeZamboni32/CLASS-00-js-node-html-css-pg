SELECT *
FROM client;
