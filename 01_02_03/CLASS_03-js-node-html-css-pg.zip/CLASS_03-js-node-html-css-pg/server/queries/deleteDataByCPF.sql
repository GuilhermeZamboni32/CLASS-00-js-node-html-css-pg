DELETE FROM client
WHERE cpf = $1
RETURNING *;
