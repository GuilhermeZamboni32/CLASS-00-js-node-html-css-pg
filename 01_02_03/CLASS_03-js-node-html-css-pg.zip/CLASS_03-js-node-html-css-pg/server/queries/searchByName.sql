SELECT *
FROM client
WHERE nome ILIKE $1;
