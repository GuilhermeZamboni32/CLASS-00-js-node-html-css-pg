SELECT *
FROM client
WHERE cpf = $1;
